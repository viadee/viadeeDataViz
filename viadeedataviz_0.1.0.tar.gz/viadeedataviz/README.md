# viadee Datenvisualisierung (R)

Idee: Wir generalisieren typische Visualisierungen, aus den Data-Mining-POCs und stellen diese als R-Package zur Verfügung.

Zunächst sind aber nur ggplot-Hintergründe im viadee-CI enthalten.

# Build
roxygen2::roxygenise()
rstudio > Build > Build Source Package